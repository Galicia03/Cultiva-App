
import SwiftUI
import UIKit
import CoreML
import Vision

struct ContentView: View {
    var body: some View {
        NavigationView {
            TabView {
                ComunidadView()
                    .tabItem {
                        Image(systemName: "person.3.fill")
                        Text("Comunidad")
                    }
                
                ExplorarView()
                    .tabItem {
                        Image(systemName: "magnifyingglass")
                        Text("Explorar")
                    }
                
                MiHuertoView()
                    .tabItem {
                        Image(systemName: "leaf.fill")
                        Text("Mi Huerto")
                    }
                
                ChatView()
                    .tabItem {
                        Image(systemName: "message.fill")
                        Text("Chat")
                    }
                
                AlertasView()
                    .tabItem {
                        Image(systemName: "bell.fill")
                        Text("Alertas")
                    }
            }
            .accentColor(.green)
        }
    }
}

// Placeholder views
struct ComunidadView: View {
    var body: some View {
        VStack {
            Text("Comunidad Screen")
                .font(.largeTitle)
                .foregroundColor(.green)
        }
    }
}

struct MiHuertoView: View {
    var body: some View {
        VStack {
            Text("Mi Huerto Screen")
                .font(.largeTitle)
                .foregroundColor(.green)
        }
    }
}

struct ChatView: View {
    var body: some View {
        VStack {
            Text("Chat Screen")
                .font(.largeTitle)
                .foregroundColor(.green)
        }
    }
}

struct AlertasView: View {
    var body: some View {
        VStack {
            Text("Alertas Screen")
                .font(.largeTitle)
                .foregroundColor(.green)
        }
    }
}

// ExplorarView with chat functionality and image identifier
struct ExplorarView: View {
    @State private var userInput: String = ""
    @State private var chatHistory: [(String, Bool)] = [] // (Message, isUser)
    @State private var isLoading: Bool = false
    @State private var showImageIdentifier: Bool = true

    // Variables for image capture and model prediction
    @State private var isShowingImagePicker = false
    @State private var imageSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var capturedImage: UIImage?
    @State private var topPrediction: (label: String, confidence: Double)?
    
    var body: some View {
        VStack {
            // Chat input and button
            TextField("Pregúntale a Cebollino", text: $userInput, onEditingChanged: { isEditing in
                if isEditing {
                    withAnimation {
                        showImageIdentifier = false
                    }
                }
            })
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()

            HStack {
                if !userInput.isEmpty {
                    Button(action: {
                        sendMessageToOpenAI()
                    }) {
                        Image(systemName: "paperplane.fill")
                            .padding()
                    }
                }
            }
            .padding()

            Divider()

            // Chat history display
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(chatHistory, id: \.0) { message, isUser in
                        HStack {
                            if isUser {
                                Spacer()
                                Text(message)
                                    .padding()
                                    .background(Color.green.opacity(0.7))
                                    .cornerRadius(10)
                                    .foregroundColor(.white)
                                    .frame(maxWidth: UIScreen.main.bounds.width * 0.7, alignment: .trailing)
                            } else {
                                Text(message)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                    .frame(maxWidth: UIScreen.main.bounds.width * 0.7, alignment: .leading)
                                Spacer()
                            }
                        }
                    }
                }
                .padding()
            }

            // Image identifier
            if showImageIdentifier {
                VStack {
                    if let image = capturedImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 300, height: 300)

                        // Display the top prediction
                        if let topPrediction = topPrediction {
                            VStack {
                                Text("Predicción: \(topPrediction.label)")
                                    .font(.headline)
                                Text("Confianza: \(String(format: "%.2f%%", topPrediction.confidence * 100))")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.top)
                        } else {
                            Text("Procesando predicción...")
                                .font(.footnote)
                        }
                    } else {
                        Image(systemName: "photo")
                            .imageScale(.large)
                            .foregroundColor(.blue)
                            .frame(width: 300, height: 300)
                    }

                    HStack {
                        Button(action: {
                            imageSourceType = .camera
                            isShowingImagePicker = true
                        }) {
                            Text("Abrir Cámara")
                                .font(.title)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }

                        Button(action: {
                            imageSourceType = .photoLibrary
                            isShowingImagePicker = true
                        }) {
                            Text("Abrir Galería")
                                .font(.title)
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                }
                .padding()
                .sheet(isPresented: $isShowingImagePicker) {
                    ImagePickerView(selectedImage: $capturedImage, isPresented: $isShowingImagePicker, sourceType: imageSourceType, onImagePicked: getModelProbabilities)
                }
            }

            if isLoading {
                ProgressView("Enviando...")
                    .padding()
            }
        }
        .padding()
    }

    // Función para obtener probabilidades del modelo
    private func getModelProbabilities(from image: UIImage) {
        guard let model = try? ClasificadorCultiva(configuration: MLModelConfiguration()) else {
            print("Error al cargar el modelo")
            return
        }

        guard let scaledImage = resizeImage(image: image, targetSize: CGSize(width: 299, height: 299)),
              let pixelBuffer = scaledImage.toCVPixelBuffer() else {
            print("Error al convertir la imagen a CVPixelBuffer")
            return
        }

        do {
            let output = try model.prediction(image: pixelBuffer)
            
            if let highestProbability = output.targetProbability.max(by: { $0.value < $1.value }) {
                topPrediction = (label: highestProbability.key, confidence: highestProbability.value)
            }
        } catch {
            print("Error en la predicción: \(error.localizedDescription)")
        }
    }

    // OpenAI function (chat)
    func sendMessageToOpenAI() {
        guard !userInput.isEmpty else { return }
        chatHistory.append((userInput, true))
        isLoading = true
        let apiKey = "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"
        guard let url = URL(string: "https://api.openai.com/v1/chat/completions") else {
            self.chatHistory.append(("Error: URL inválida.", false))
            self.isLoading = false
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "model": "gpt-3.5-turbo",
            "messages": [
                ["role": "system", "content": "You are a helpful assistant."],
                ["role": "user", "content": userInput]
            ],
            "max_tokens": 1000,
            "temperature": 0.2
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        userInput = ""
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
            }
            if let error = error {
                DispatchQueue.main.async {
                    self.chatHistory.append(("Error: \(error.localizedDescription)", false))
                }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async {
                    self.chatHistory.append(("Error: No se recibió respuesta.", false))
                }
                return
            }
            do {
                if let jsonObject = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let choices = jsonObject["choices"] as? [[String: Any]],
                   let message = choices.first?["message"] as? [String: Any],
                   let text = message["content"] as? String {
                    DispatchQueue.main.async {
                        self.chatHistory.append((text.trimmingCharacters(in: .whitespacesAndNewlines), false))
                    }
                } else if let jsonObject = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                          let error = jsonObject["error"] as? [String: Any] {
                    let errorMessage = error["message"] as? String ?? "Unknown error"
                    DispatchQueue.main.async {
                        self.chatHistory.append(("Error: \(errorMessage)", false))
                    }
                } else {
                    DispatchQueue.main.async {
                        self.chatHistory.append(("Error: No se pudo interpretar la respuesta.", false))
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.chatHistory.append(("Error: \(error.localizedDescription)", false))
                }
            }
        }.resume()
    }

    // Función para redimensionar la imagen
    private func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage? {
        let size = image.size
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        let scaleFactor = min(widthRatio, heightRatio)
        let newSize = CGSize(width: size.width * scaleFactor, height: size.height * scaleFactor)

        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: CGRect(origin: .zero, size: newSize))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage
    }
}

// ImagePicker for camera or gallery
struct ImagePickerView: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?
    @Binding var isPresented: Bool
    var sourceType: UIImagePickerController.SourceType
    var onImagePicked: (UIImage) -> Void  // Closure para manejar la imagen seleccionada

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePickerView

        init(parent: ImagePickerView) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.selectedImage = uiImage
                parent.onImagePicked(uiImage)  // Llamamos a la función de predicción con la imagen seleccionada
            }
            parent.isPresented = false
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.isPresented = false
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
}

// Extensión para convertir UIImage a CVPixelBuffer
extension UIImage {
    func toCVPixelBuffer() -> CVPixelBuffer? {
        let attributes: [NSObject: AnyObject] = [
            kCVPixelBufferCGImageCompatibilityKey: true as AnyObject,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true as AnyObject
        ]

        var pixelBuffer: CVPixelBuffer?
        let width = Int(self.size.width)
        let height = Int(self.size.height)

        let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32ARGB, attributes as CFDictionary, &pixelBuffer)
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(buffer, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(buffer)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pixelData, width: width, height: height, bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(buffer), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else {
            return nil
        }

        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))
        UIGraphicsPopContext()

        CVPixelBufferUnlockBaseAddress(buffer, CVPixelBufferLockFlags(rawValue: 0))

        return buffer
    }
}


