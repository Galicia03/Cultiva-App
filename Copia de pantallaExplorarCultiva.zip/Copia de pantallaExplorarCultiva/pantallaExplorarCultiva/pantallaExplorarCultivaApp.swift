//
//  pantallaExplorarCultivaApp.swift
//  pantallaExplorarCultiva
//
//  Created by CETYS Universidad  on 19/10/24.
//

import SwiftUI

@main
struct pantallaExplorarCultivaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
